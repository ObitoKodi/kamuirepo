# RetrOSMC Launcher for OSMC
Update containing fixes and rebranding of the RetrOSMC launcher from this script: https://github.com/mcobit/retrosmc

![Add-on Configuration](https://i.imgur.com/WCtrJwq.jpg)

## Credits
* `mcobit` who developed the RetrOSMC installer script: https://github.com/mcobit/retrosmc
* `jcnventura3` for the original launcher add-on
* `gabrielmagno` who fixed executable shortcut issue that I've included: https://github.com/mcobit/retrosmc/pull/55

http://dev.grantgarrison.com
