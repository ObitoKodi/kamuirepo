# -*- encoding: utf-8 -*-

from twitch.oauth.v5 import scopes
