# -*- encoding: utf-8 -*-

__all__ = ['scopes']

from . import scopes
