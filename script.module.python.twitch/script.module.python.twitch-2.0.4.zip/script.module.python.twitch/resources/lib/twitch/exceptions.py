# -*- encoding: utf-8 -*-


class ResourceUnavailableException(Exception):
    pass
